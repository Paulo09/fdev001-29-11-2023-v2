const apiKey = 'OPIUR23U08-URIJIJF08-FM40JV80JBV4BI0';
export default apiKey;